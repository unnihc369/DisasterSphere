// AboutUs.js
import React from 'react';
import './AboutUs.css';

const AboutUs = () => {
    return (
        <div className="about-container">
            <header className="about-header">
                <h1>About Us</h1>
                <p>Learn more about our team, mission, and values.</p>
            </header>
            <section className="about-section">
                <div className="about-image">
                    <img src="https://via.placeholder.com/500" alt="About Us" />
                </div>
                <div className="about-content">
                    <h2>Our Mission</h2>
                    <p>Our mission is to provide exceptional services and solutions that meet the diverse needs of our clients. We strive to foster a culture of innovation, collaboration, and integrity in all our endeavors.</p>
                </div>
            </section>
            <section className="about-section reverse">
                <div className="about-image">
                    <img src="https://via.placeholder.com/500" alt="Our Team" />
                </div>
                <div className="about-content">
                    <h2>Our Team</h2>
                    <p>We are a team of passionate professionals dedicated to making a positive impact. Our diverse backgrounds and expertise enable us to tackle challenges and deliver results effectively.</p>
                </div>
            </section>
            <section className="about-section">
                <div className="about-image">
                    <img src="https://via.placeholder.com/500" alt="Our Values" />
                </div>
                <div className="about-content">
                    <h2>Our Values</h2>
                    <p>We believe in integrity, excellence, and respect. These core values guide our actions and decisions, ensuring that we deliver quality services and maintain strong relationships with our clients and partners.</p>
                </div>
            </section>
        </div>
    );
};

export default AboutUs;
