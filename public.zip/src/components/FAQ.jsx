// FAQ.js
import React, { useState } from 'react';
import './FAQ.css';

const FAQ = () => {
    const [selectedQuestion, setSelectedQuestion] = useState(null);

    const toggleQuestion = (index) => {
        setSelectedQuestion(selectedQuestion === index ? null : index);
    };

    const faqData = [
        {
            question: "What is your return policy?",
            answer: "Our return policy is 30 days. No questions asked. Simply return the item in its original condition and packaging."
        },
        {
            question: "How do I track my order?",
            answer: "You can track your order using the tracking number provided in your order confirmation email."
        },
        {
            question: "Can I purchase items available online at the store?",
            answer: "Yes, most items available online can also be purchased at our physical stores. Please check availability before visiting."
        },
        {
            question: "How can I contact customer support?",
            answer: "You can contact our customer support team via email at support@example.com or by phone at (123) 456-7890."
        }
    ];

    return (
        <div className="faq-container">
            <h1 className="faq-header">Frequently Asked Questions</h1>
            <div className="faq-list">
                {faqData.map((item, index) => (
                    <div
                        key={index}
                        className={`faq-item ${selectedQuestion === index ? 'active' : ''}`}
                        onClick={() => toggleQuestion(index)}
                    >
                        <div className="faq-question">
                            {item.question}
                            <span className="faq-icon">{selectedQuestion === index ? '-' : '+'}</span>
                        </div>
                        {selectedQuestion === index && <div className="faq-answer">{item.answer}</div>}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default FAQ;
