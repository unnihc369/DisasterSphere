// src/components/Admin.jsx
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchUsers, updateUserAdminStatus } from '../redux/allUsersSlice';
import UserList from '../components/UserList';
import StatsCard from '../components/StatsCard';
import './Admin.css'
import { redirect, useNavigate } from 'react-router-dom';

const Admin = () => {
    const dispatch = useDispatch();
    const user = useSelector((state) => state.user.user);
    const users = useSelector((state) => state.users.users);
    const status = useSelector((state) => state.users.status);
    const navigate = useNavigate();

    useEffect(() => {
        if (!user.isAdmin) {
            return <Navigate to={'/login'} replace />;
        }
    }, [user.isAdmin]);

    useEffect(() => {
        if (status === 'idle') {
            dispatch(fetchUsers());
        }
    }, [status, dispatch]);

    const makeAdmin = (id) => {
        const user = users.find(user => user._id === id);
        if (user) {
            dispatch(updateUserAdminStatus({ id, isAdmin: !user.isAdmin }));
        }
    };

    const adminCount = users.filter(user => user.isAdmin).length;

    return (
        <div className="admin-panel">
            {(!user.isAdmin || !user )&& <Navigate to="/login" replace />}
            <h1>Admin Panel</h1>
            <div className="stats">
                <StatsCard title="Total Users" count={users.length} />
                <StatsCard title="Total Admins" count={adminCount} />
                <StatsCard title="Total Posts" count={20} /> {/* Example static post count */}
            </div>
            <UserList users={users} makeAdmin={makeAdmin} />
        </div>
    );
};

export default Admin;
