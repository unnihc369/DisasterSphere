import React, { useState } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import './Signup.css';
import { storage } from '../firebase';

const Signup = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [profileImage, setProfileImage] = useState(null); // State for storing profile image
    const [loading, setLoading] = useState(false);

    const handleImageChange = (e) => {
        if (e.target.files[0]) {
            setProfileImage(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        let imageUrl = '';

        // If a profile image is selected, upload it to Firebase Storage
        if (profileImage) {
            const imageRef = ref(storage, `profiles/${profileImage.name}`);
            const uploadTask = uploadBytesResumable(imageRef, profileImage);

            // Await the upload and get the download URL
            await uploadTask.then((snapshot) => {
                return getDownloadURL(snapshot.ref);
            }).then((url) => {
                imageUrl = url;
            }).catch((error) => {
                toast.error('Failed to upload image');
                setLoading(false);
                return;
            });
        }

        try {
            const response = await fetch('http://localhost:5000/user/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name,
                    email,
                    password,
                    profileImage: imageUrl // Include the image URL in the request body
                })
            });

            const data = await response.json();
            if (response.ok) {
                toast.success(data.message);
                setName('');
                setEmail('');
                setPassword('');
                setProfileImage(null); 
            } else {
                toast.error(data.error);
            }
        } catch (error) {
            toast.error('Something went wrong. Please try again.');
        }
        setLoading(false);
    };

    return (
        <div className="signup-container">
            <Toaster />
            <div className="signup-form-container">
                <h1>Sign Up</h1>
                <form onSubmit={handleSubmit} className="signup-form">
                    <div className="form-group">
                        <label htmlFor="name">Name</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="email">Email</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="profileImage">Profile Image</label>
                        <input
                            type="file"
                            id="profileImage"
                            accept="image/*"
                            onChange={handleImageChange}
                        />
                    </div>
                    <button type="submit" className="submit-button" disabled={loading}>
                        {loading ? 'Signing Up...' : 'Sign Up'}
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Signup;
